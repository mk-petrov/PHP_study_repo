<?php

/* base.html.twig */
class __TwigTemplate_e8fc349c2544a7f0ea783b2f16a9beefe423c06e248ca02a5d628996118139f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6114414f476cfa9c58d0ac53063acbf9c0ed25422f0122d0953ebf2f3c5a2a1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6114414f476cfa9c58d0ac53063acbf9c0ed25422f0122d0953ebf2f3c5a2a1f->enter($__internal_6114414f476cfa9c58d0ac53063acbf9c0ed25422f0122d0953ebf2f3c5a2a1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>


";
        // line 51
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "
</body>
</html>
";
        
        $__internal_6114414f476cfa9c58d0ac53063acbf9c0ed25422f0122d0953ebf2f3c5a2a1f->leave($__internal_6114414f476cfa9c58d0ac53063acbf9c0ed25422f0122d0953ebf2f3c5a2a1f_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_87cb36c17a90de8eb5dac2e4a8c5b5592ff37a0551317eb84ebaae1ecf90cc10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87cb36c17a90de8eb5dac2e4a8c5b5592ff37a0551317eb84ebaae1ecf90cc10->enter($__internal_87cb36c17a90de8eb5dac2e4a8c5b5592ff37a0551317eb84ebaae1ecf90cc10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_87cb36c17a90de8eb5dac2e4a8c5b5592ff37a0551317eb84ebaae1ecf90cc10->leave($__internal_87cb36c17a90de8eb5dac2e4a8c5b5592ff37a0551317eb84ebaae1ecf90cc10_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_8d63f7953afbc4e20cbfcaf51b84a0a5c22cd25a2728efc46cab8bd3226bc170 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d63f7953afbc4e20cbfcaf51b84a0a5c22cd25a2728efc46cab8bd3226bc170->enter($__internal_8d63f7953afbc4e20cbfcaf51b84a0a5c22cd25a2728efc46cab8bd3226bc170_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_8d63f7953afbc4e20cbfcaf51b84a0a5c22cd25a2728efc46cab8bd3226bc170->leave($__internal_8d63f7953afbc4e20cbfcaf51b84a0a5c22cd25a2728efc46cab8bd3226bc170_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_af53bc20e2f9ea7c94c867f5640978e4f85b103e6ee041833d2e801cd43e48ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af53bc20e2f9ea7c94c867f5640978e4f85b103e6ee041833d2e801cd43e48ac->enter($__internal_af53bc20e2f9ea7c94c867f5640978e4f85b103e6ee041833d2e801cd43e48ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_af53bc20e2f9ea7c94c867f5640978e4f85b103e6ee041833d2e801cd43e48ac->leave($__internal_af53bc20e2f9ea7c94c867f5640978e4f85b103e6ee041833d2e801cd43e48ac_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_4bbc2e126b3b3e10910e3ea4ccbb54b42f5b62dc7a483489fdaf91c755763fcb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bbc2e126b3b3e10910e3ea4ccbb54b42f5b62dc7a483489fdaf91c755763fcb->enter($__internal_4bbc2e126b3b3e10910e3ea4ccbb54b42f5b62dc7a483489fdaf91c755763fcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_4bbc2e126b3b3e10910e3ea4ccbb54b42f5b62dc7a483489fdaf91c755763fcb->leave($__internal_4bbc2e126b3b3e10910e3ea4ccbb54b42f5b62dc7a483489fdaf91c755763fcb_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_1f964fb194b5fbdc247d8badd08eb95b58dbcf931256566307f6b094534876ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f964fb194b5fbdc247d8badd08eb95b58dbcf931256566307f6b094534876ad->enter($__internal_1f964fb194b5fbdc247d8badd08eb95b58dbcf931256566307f6b094534876ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_1f964fb194b5fbdc247d8badd08eb95b58dbcf931256566307f6b094534876ad->leave($__internal_1f964fb194b5fbdc247d8badd08eb95b58dbcf931256566307f6b094534876ad_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_472659f50f87a2b0323dd8b0391cf31c59e76c3c2275f2a9c86fc8af38173670 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_472659f50f87a2b0323dd8b0391cf31c59e76c3c2275f2a9c86fc8af38173670->enter($__internal_472659f50f87a2b0323dd8b0391cf31c59e76c3c2275f2a9c86fc8af38173670_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_472659f50f87a2b0323dd8b0391cf31c59e76c3c2275f2a9c86fc8af38173670->leave($__internal_472659f50f87a2b0323dd8b0391cf31c59e76c3c2275f2a9c86fc8af38173670_prof);

    }

    // line 51
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f460d5a93ebfcac9cbcf3bdfb083fa459507ba7d7fc833835827d46659617158 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f460d5a93ebfcac9cbcf3bdfb083fa459507ba7d7fc833835827d46659617158->enter($__internal_f460d5a93ebfcac9cbcf3bdfb083fa459507ba7d7fc833835827d46659617158_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 52
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_f460d5a93ebfcac9cbcf3bdfb083fa459507ba7d7fc833835827d46659617158->leave($__internal_f460d5a93ebfcac9cbcf3bdfb083fa459507ba7d7fc833835827d46659617158_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 55,  201 => 54,  197 => 53,  192 => 52,  186 => 51,  175 => 44,  166 => 45,  164 => 44,  160 => 42,  154 => 41,  134 => 26,  128 => 22,  122 => 21,  111 => 19,  102 => 14,  97 => 13,  91 => 12,  79 => 11,  69 => 57,  67 => 51,  62 => 48,  60 => 41,  56 => 39,  54 => 21,  49 => 19,  42 => 16,  40 => 12,  36 => 11,  29 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>


{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
